# Crypto Volatility Prediction

This project predicts cryptocurrency volatility using historical data and machine learning techniques.
